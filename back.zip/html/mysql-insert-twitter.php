<?php

$servername = "localhost";
$username = "root";
$password = "Hacking456!";
$dbname = "Tendencias";
header('Access-Control-Allow-Origin: *');

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"https://api.twitter.com/1.1/trends/place.json?id=375732");


curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 


$headers = [
    "Authorization: Bearer AAAAAAAAAAAAAAAAAAAAAEZJhwEAAAAAm2MzKMt41TKhpXdHdWW4rsVZhEw%3D1r831LA5HcgQeUKug7f75I0r7uUaswrP0VFpGMXzLxXSlxLvDh",
    "Accept: application/json",
    "Content-Type:application/json"
];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$server_output = curl_exec ($ch);

curl_close ($ch);

$decode1=substr($server_output, 1, -1);
$decode = json_decode($decode1);
foreach($decode->trends as $tweet)
{
  for ($i=0; $i< count($decode); $i++) {
     $name = strval($tweet->name);
     $query= strval($tweet->query);
     $tweet_volume=$tweet->tweet_volume?$tweet->tweet_volume:0;
     $url=strval($tweet->url);
    $sql = "INSERT INTO twitter (name, query, tweet_volume, url)
    VALUES ('$name', '$query', $tweet_volume, '$url')";
    $result = $conn->query($sql);
  }
}

